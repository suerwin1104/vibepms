
# 備份腳本 - Backup Script for Windows (PowerShell)

$projectName = "vibepms"
$backupDir = "backups"
$timestamp = Get-Date -Format "yyyyMMdd_HHmm"
$backupFile = "${projectName}_backup_${timestamp}.zip"

# 建立備份資料夾 (如果不存在)
if (!(Test-Path $backupDir)) {
    New-Item -ItemType Directory -Path $backupDir | Out-Null
    Write-Host "建立備份資料夾: $backupDir" -ForegroundColor Cyan
}

Write-Host "開始備份專案..." -ForegroundColor Yellow

# 定義要排除的資料夾
$excludeList = @('node_modules', '.git', 'dist', 'build', 'backups', '.next', 'tmp')

# 取得所有檔案，排除特定資料夾
# 我們先獲取根目錄下的所有項，過濾掉排除名單，然後遞迴
$itemsToCompress = Get-ChildItem -Path "." | Where-Object { $excludeList -notcontains $_.Name }

if ($itemsToCompress) {
    # 執行壓縮
    Compress-Archive -Path $itemsToCompress.FullName -DestinationPath "$backupDir\$backupFile" -Force
    
    $fullPath = Resolve-Path "$backupDir\$backupFile"
    Write-Host "`n備份成功！" -ForegroundColor Green
    Write-Host "備份檔案位於: $fullPath" -ForegroundColor White
} else {
    Write-Host "找不到要備份的檔案。" -ForegroundColor Red
}
