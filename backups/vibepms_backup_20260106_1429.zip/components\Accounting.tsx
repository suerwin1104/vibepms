
import React from 'react';
import { Invoice } from '../types';

interface Props {
  invoices: Invoice[];
  hotelId: string;
  onVoid?: (id: string) => void;
  onPrint?: (inv: Invoice, layout: 'A4' | 'POS') => void;
}

const Accounting: React.FC<Props> = ({ invoices, hotelId, onVoid, onPrint }) => {
  // 僅統計當前飯店的發票
  const hotelInvoices = invoices.filter(i => i.hotelId === hotelId);

  return (
    <div className="space-y-6">
      <header className="flex justify-between items-end">
        <div>
          <h2 className="text-2xl font-black text-slate-800">分店財務報表</h2>
          <p className="text-sm text-slate-500 font-medium">僅顯示當前選定分店的開票與營收紀錄。</p>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3 bg-white border border-slate-200 rounded-[32px] overflow-hidden shadow-sm">
          <table className="w-full text-left">
            <thead className="bg-slate-900 text-amber-500 text-[10px] uppercase font-black tracking-widest">
              <tr>
                <th className="px-6 py-5">發票號碼</th>
                <th className="px-6 py-5 text-right">金額</th>
                <th className="px-6 py-5 text-center">狀態</th>
                <th className="px-6 py-5">開立人</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {hotelInvoices.map(inv => (
                <tr key={inv.id} className="text-sm font-bold group hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4 font-mono">{inv.invoiceNumber}</td>
                  <td className="px-6 py-4 text-right font-black">${inv.amount.toLocaleString()}</td>
                  <td className="px-6 py-4 text-center">
                    <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-blue-50 text-blue-600">
                      {inv.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-slate-400 font-medium">{inv.createdBy}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {hotelInvoices.length === 0 && (
            <div className="p-24 text-center text-slate-300 italic">目前該分店無開票數據</div>
          )}
        </div>

        <div className="bg-slate-900 p-8 rounded-[32px] text-white shadow-xl h-fit">
          <h3 className="text-[10px] font-black text-slate-500 uppercase mb-4 tracking-widest">分店營收總計</h3>
          <p className="text-5xl font-black text-blue-500 tracking-tighter">
            ${hotelInvoices.filter(i => i.status === 'Active').reduce((sum, i) => sum + i.amount, 0).toLocaleString()}
          </p>
          <div className="mt-8 pt-8 border-t border-slate-800 space-y-4">
            <div className="flex justify-between text-xs text-slate-400 font-bold">
              <span>發票單數:</span>
              <span className="text-white">{hotelInvoices.length} 筆</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Accounting;
