
import React from 'react';
import { Reservation, Room, RoomStatus } from '../types';

interface Props {
  reservations: Reservation[];
  rooms: Room[];
  onCheckIn: (id: string) => void;
}

const DailyArrivals: React.FC<Props> = ({ reservations, rooms, onCheckIn }) => {
  // 顯示所有「今天」且狀態為「已確認」的訂單
  const arrivals = reservations.filter(r => r.status === 'Confirmed');

  return (
    <div className="space-y-6">
      <header className="flex justify-between items-end">
        <div>
          <h2 className="text-2xl font-black text-slate-800">今日抵達名單 (Arrivals)</h2>
          <p className="text-sm text-slate-500 font-medium italic">系統會自動檢測分配房間是否已清潔 (VC)，確保房客抵達即可入住。</p>
        </div>
        <div className="bg-slate-900 text-white px-4 py-2 rounded-2xl text-xs font-black shadow-lg">
          待處理: {arrivals.length} 筆
        </div>
      </header>

      <div className="grid grid-cols-1 gap-4">
        {arrivals.map(res => {
          const assignedRoom = rooms.find(r => r.number === res.roomNumber);
          // 只有 VC (空淨) 或 SO (續住整理) 才能辦理入住，或者強制覆蓋
          const isReady = assignedRoom?.status === RoomStatus.VC;

          return (
            <div key={res.id} className="bg-white border border-slate-200 p-6 rounded-3xl shadow-sm flex items-center justify-between group hover:border-blue-400 transition-all">
              <div className="flex items-center gap-8">
                <div className="text-center bg-slate-900 text-white p-4 rounded-2xl min-w-[120px] shadow-xl group-hover:scale-105 transition-transform">
                  <p className="text-[10px] font-black text-slate-500 uppercase mb-1">ALLOCATED</p>
                  <p className="text-3xl font-black">#{res.roomNumber}</p>
                </div>
                <div>
                  <h4 className="font-black text-slate-800 text-xl flex items-center gap-2">
                    {res.guestName}
                    <span className="bg-blue-50 text-blue-600 text-[10px] px-2 py-0.5 rounded font-black">{res.roomType}</span>
                  </h4>
                  <p className="text-xs text-slate-500 font-bold mt-1 uppercase tracking-widest">ORDER: {res.id} • {res.source}</p>
                </div>
              </div>

              <div className="flex items-center gap-10">
                <div className="text-right">
                  <p className="text-[10px] font-black text-slate-400 uppercase mb-1">房務整備狀態</p>
                  <span className={`px-3 py-1.5 rounded-xl text-xs font-black uppercase border-2 ${isReady ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-rose-50 text-rose-500 border-rose-100 animate-pulse'}`}>
                    {assignedRoom?.status || 'N/A'} {isReady ? '✓ 已可入住' : '⏳ 等待清掃'}
                  </span>
                </div>
                <button 
                  disabled={!isReady}
                  onClick={() => onCheckIn(res.id)}
                  className={`px-8 py-4 rounded-2xl font-black text-sm shadow-xl transition-all ${isReady ? 'bg-blue-600 text-white hover:bg-blue-700 active:scale-95' : 'bg-slate-100 text-slate-300 cursor-not-allowed grayscale'}`}
                >
                  辦理入住 Check-in
                </button>
              </div>
            </div>
          );
        })}
        {arrivals.length === 0 && (
          <div className="py-24 text-center bg-white rounded-[40px] border-2 border-dashed border-slate-200">
            <div className="text-5xl mb-4 grayscale opacity-20">🧳</div>
            <p className="text-slate-400 font-black italic">今日暫無待處理之抵達名單，所有賓客已妥善安置。</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default DailyArrivals;
