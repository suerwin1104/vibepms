
import React from 'react';
import { Invoice, Hotel, Reservation, Guest } from '../types';

interface InvoiceReceiptProps {
  invoice: Invoice;
  hotel: Hotel;
  reservation?: Reservation;
  guest?: Guest;
  layout: 'A4' | 'POS';
}

const InvoiceReceipt: React.FC<InvoiceReceiptProps> = ({ invoice, hotel, reservation, guest, layout }) => {
  const isVoided = invoice.status === 'Voided';

  return (
    <div
      id="printable-invoice"
      className={`print-receipt-container bg-white text-slate-900 ${layout === 'POS' ? 'pos-layout' : 'a4-layout'
        }`}
    >
      <style>{`
        /* 螢幕顯示模式：將組件移出視窗外但保持在 DOM 中 */
        @media screen {
          .print-receipt-container {
            position: absolute !important;
            left: -9999px !important;
            top: -9999px !important;
            height: 1px !important;
            width: 1px !important;
            overflow: hidden !important;
            opacity: 0 !important;
          }
        }

        /* 列印模式：隱藏導覽列與側邊欄，僅顯示內容 */
        @media print {
          /* 隱藏外層不需要的內容 */
          .no-print, nav, aside { 
            display: none !important; 
          }
          
          /* 核心列印容器：確保它被顯示 */
          #printable-invoice {
            display: block !important;
            visibility: visible !important;
            position: fixed !important;
            left: 0 !important;
            top: 0 !important;
            width: 100% !important;
            margin: 0 !important;
            padding: ${layout === 'POS' ? '2mm' : '15mm'} !important;
            background: white !important;
            z-index: 9999999 !important;
          }

          /* 確保所有父層元素不會因為 overflow:hidden 或是 visibility 被切掉 */
          body, #root, main, .max-w-7xl {
            overflow: visible !important;
            visibility: visible !important;
            display: block !important;
            height: auto !important;
          }
          
          .a4-layout {
            width: 210mm !important;
            min-height: 297mm !important;
            font-size: 11pt !important;
          }

          .pos-layout {
            width: 80mm !important;
            font-size: 9pt !important;
            line-height: 1.3 !important;
          }

          @page {
            margin: 0;
            size: ${layout === 'POS' ? '80mm auto' : 'A4'};
          }
        }
        
        .watermark {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%) rotate(-45deg);
          font-size: 60px;
          font-weight: 900;
          color: rgba(220, 38, 38, 0.1);
          white-space: nowrap;
          pointer-events: none;
          z-index: 0;
          border: 8px solid rgba(220, 38, 38, 0.1);
          padding: 10px 20px;
          text-transform: uppercase;
        }
      `}</style>

      {isVoided && <div className="watermark">VOIDED / 已作廢</div>}

      <div className="relative z-10">
        {/* Header */}
        <div className={`border-b-4 border-slate-900 mb-6 flex justify-between items-end ${layout === 'POS' ? 'pb-2' : 'pb-6'}`}>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-8 h-8 bg-slate-900 text-white flex items-center justify-center font-black text-xl rounded">H</div>
              <h1 className={`${layout === 'POS' ? 'text-lg' : 'text-2xl'} font-black tracking-tighter uppercase`}>{hotel.name}</h1>
            </div>
            <p className="text-[9pt] font-bold">{hotel.address}</p>
            <p className="text-[9pt]">統一編號: 88889999 | TEL: {hotel.phone}</p>
          </div>
          <div className="text-right">
            <h2 className={`${layout === 'POS' ? 'text-sm' : 'text-lg'} font-black text-blue-600`}>電子發票證明聯</h2>
            <p className="font-mono font-black mt-1 text-xl tracking-tighter">{invoice.invoiceNumber}</p>
            <p className="text-[8pt] font-bold text-slate-500">{invoice.createdAt}</p>
          </div>
        </div>

        {/* Customer Info */}
        <div className={`grid ${layout === 'POS' ? 'grid-cols-1 gap-2' : 'grid-cols-2 gap-10'} mb-6`}>
          <div className="border-l-4 border-slate-100 pl-4">
            <p className="text-[8pt] font-black text-slate-400 uppercase tracking-widest mb-1">買受人資訊 (Guest)</p>
            <p className="text-md font-black">{reservation?.guestName || guest?.name || '臨住房客'}</p>
            <p className="font-mono text-[8pt] text-slate-500">ID: {reservation?.idNumber || guest?.idNumber || 'N/A'}</p>
          </div>
          <div className={`${layout === 'POS' ? 'text-left border-l-4 border-slate-100 pl-4' : 'text-right'}`}>
            <p className="text-[8pt] font-black text-slate-400 uppercase tracking-widest mb-1">交易資訊 (Booking)</p>
            <p className="font-bold">單號: {reservation?.id || 'WALK-IN'}</p>
            <p className="font-black text-blue-600">房號: #{reservation?.roomNumber || 'N/A'}</p>
          </div>
        </div>

        {/* Details Table */}
        <table className="w-full mb-8">
          <thead className="bg-slate-50 border-y-2 border-slate-900">
            <tr className="text-left font-black uppercase text-[8pt] text-slate-500">
              <th className="py-2 px-1">品名項目 Description</th>
              <th className="py-2 text-right px-1">金額 Amt</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 font-bold">
            <tr>
              <td className="py-4 px-1">
                <div className="text-[10pt]">房租收入 ({reservation?.roomType || 'Standard'})</div>
                <div className="text-[8pt] text-slate-400 font-normal italic">
                  期間: {reservation?.checkIn || '-'} 至 {reservation?.checkOut || '-'}
                </div>
              </td>
              <td className="py-4 text-right font-mono px-1">${invoice.amount.toLocaleString()}</td>
            </tr>
          </tbody>
        </table>

        {/* Summary */}
        <div className="flex justify-end mb-10">
          <div className={`${layout === 'POS' ? 'w-full' : 'w-72'} space-y-2 bg-slate-50 p-5 rounded-2xl border-2 border-slate-100`}>
            <div className="flex justify-between text-[9pt] font-bold text-slate-500">
              <span>銷售額 (Net)</span>
              <span className="font-mono">${invoice.netAmount.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-[9pt] font-bold text-slate-500">
              <span>營業稅 (Tax 5%)</span>
              <span className="font-mono">${invoice.tax.toLocaleString()}</span>
            </div>
            <div className={`flex justify-between border-t-2 border-slate-300 pt-2 font-black text-slate-900 ${layout === 'POS' ? 'text-xl' : 'text-2xl'}`}>
              <span>總計 TOTAL</span>
              <span className="font-mono tracking-tighter">${invoice.amount.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-slate-200 pt-6">
          <div className="flex justify-between items-start">
            <div className="text-[8pt] text-slate-400 font-bold max-w-md space-y-1">
              <p>※ 本單據僅供內部對帳或報帳使用，不具中獎資格。</p>
              <p>※ HotelGroup PMS Certified System: {invoice.id}</p>
            </div>
            <div className="text-right">
              <p className="text-[9pt] font-black text-slate-900 uppercase mb-4">經辦人員 Signature</p>
              <p className="text-lg font-serif italic text-blue-800 border-b border-blue-200 px-4">{invoice.createdBy}</p>
            </div>
          </div>
          <p className="mt-8 text-center text-[9pt] text-slate-300 font-black uppercase tracking-[0.4em]">--- Thank you for your stay ---</p>
        </div>
      </div>
    </div>
  );
};

export default InvoiceReceipt;
